package com.acharya.classes;

public class Sumofarrays {

	public static void main(String[] args) {
		int arr[] = { 12, 21, 11, 43 };
		int sum = 0;

		for (int i = 0; i < arr.length; i++) {
			sum += arr[i];

		}
		System.out.println(sum);

	}
}
