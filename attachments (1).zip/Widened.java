package java1;

public class Widened {

	public static void main(String[] args) {
	 int y=20000;
	 int x=10000;
	 int ans = x*y;
	 long l=(long)x*y;
			 
		System.out.println("Before converting"+ans);
		
		System.out.println("after converting"+l);

	}

}
