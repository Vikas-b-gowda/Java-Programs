package java1;

public class Switch {
	public static void main(String srgs[]) {
		
	}

}
