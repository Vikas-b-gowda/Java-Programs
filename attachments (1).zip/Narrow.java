package java1;

public class Narrow {

	public static void main(String[] args) {
		int i =10;
		
		long l =i;
		double d=i;
		System.out.println("int i ="+i);
		System.out.println("long l="+l);
		System.out.println("double d="+d);
	}

}
