package java1;

public class Float {

	public static void main(String[] args) {
		
		float d=(float)15/10;
	
		System.out.println("long = "+d);
		

	}

}
