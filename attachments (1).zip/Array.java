package java1;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {1,2,3,4,5};
		
		System.out.println("the array's third element is = "+arr[2]);

	}

}
