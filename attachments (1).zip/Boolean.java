package java1;

public class Boolean {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    boolean b=false;
    boolean c=true;
    int d=10;
    if(d==14654) {
    	System.out.println(c);
    }else {
    	System.out.println(b);
    }
	}

}
