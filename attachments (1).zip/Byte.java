package java1;

public class Byte {

	public static void main(String[] args) {
	int a=50;
	double b=200;
	byte c=-55;
	float d=-1000;
	

	System.out.println(a);
	System.out.println(b);
	System.out.println(c);
	System.out.println(d);
	}

}
