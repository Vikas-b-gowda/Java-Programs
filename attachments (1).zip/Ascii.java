package java1;

public class Ascii {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     char c = 'A';
     System.out.println("WORD = "+c);
     int a=(char)c;
     System.out.println("ASCII VALUE = "+a);
	}

}
