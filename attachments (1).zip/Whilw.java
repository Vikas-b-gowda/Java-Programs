package java1;

public class Whilw {
	public static void main(String args[]) {
		int x= 10;
		while(x<=50) {
			System.out.println("x = "+x);
			x=x+5;
			
		}
	}

}
